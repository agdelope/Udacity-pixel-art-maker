>> Pixel Art Maker Project URL
https://github.com/agdelope/Udacity-pixel-art-maker

Hello!

This is the Javascript final for the Intro to Programming nanodegree.
I submitted a different Javascript code to start with but I got stuck trying to fix things so after visiting the community forum I decided to start from scratch and submit the project again.

>> Instructions
Unzip file.
Open the "Index.html" file in the browser, I used chrome.

You will see options for height & width that you can adjust. Click submit and the grid will appear.

After, you can choose a colour by typing it.

With the color selected, click on any cell and you will see that it populates the pixels with the color selected!